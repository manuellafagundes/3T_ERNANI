 // IMPORTANDO MÓDULOS
import {nome, olaPessoa, textoMaiusculas} from './lib/string.js'
// IMPORTAÇÃO DE DEFAULT
import textoMinusculas from './lib/string.js'

console.log(nome)

olaPessoa()
textoMaiusculas("Morango")

textoMinusculas("Morango")
textoMaiusculas("Marcus")