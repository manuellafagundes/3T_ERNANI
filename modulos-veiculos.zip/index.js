import {acelerar} from "./lib/veiculo.js";

import {fs} from "./lib/modulo.cjs";

console.log(acelerar());
console.log(acelerar());
console.log(acelerar());
console.log(fs);