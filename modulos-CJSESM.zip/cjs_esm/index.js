// PONTO CENTRAL DA APP
import {carro} from "./libe/carro.js";

import { fs } from "./libe/modulo.cjs";

//USANDO MÓDULO PERSONALIZADO 
console.log(carro());
//USANDO MÓDULO NATIVO
console.log(fs);
  